# Autowiring in Spring

This is an example module for Autowiring in Spring.