package guru.springframework.helloservice.client;

import lombok.Value;

@Value
public class User {
    String name;
    String surname;
}
