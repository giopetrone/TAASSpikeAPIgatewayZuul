package guru.springframework.usersservice.users;

import lombok.Value;

@Value
class User {
    String name;
    String surname;
}
