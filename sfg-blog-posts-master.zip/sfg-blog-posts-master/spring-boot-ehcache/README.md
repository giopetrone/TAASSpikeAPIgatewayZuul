# Using Ehcache in Spring Boot

Example project for blog post about using Ehcache in Spring Boot applications.