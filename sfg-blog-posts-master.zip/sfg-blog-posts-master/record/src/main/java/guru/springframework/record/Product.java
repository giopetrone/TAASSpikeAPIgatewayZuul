package guru.springframework.record;

public record Product(String name, double price) {}
