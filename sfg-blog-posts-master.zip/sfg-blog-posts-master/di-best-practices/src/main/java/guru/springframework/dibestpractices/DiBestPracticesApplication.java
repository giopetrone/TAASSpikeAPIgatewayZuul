package guru.springframework.dibestpractices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiBestPracticesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiBestPracticesApplication.class, args);
	}

}
