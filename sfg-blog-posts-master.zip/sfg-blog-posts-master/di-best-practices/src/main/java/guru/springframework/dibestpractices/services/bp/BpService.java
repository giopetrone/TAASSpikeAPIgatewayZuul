package guru.springframework.dibestpractices.services.bp;

/**
 * Created by jt on 12/7/19.
 */
public interface BpService {

    String getHello();
}
