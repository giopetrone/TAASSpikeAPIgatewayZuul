package guru.springframework.dibestpractices.services;

import org.springframework.stereotype.Service;

/**
 * Created by jt on 12/7/19.
 */
@Service
public class MyService {

    public String getHello(){
        return "Hello";
    }
}
