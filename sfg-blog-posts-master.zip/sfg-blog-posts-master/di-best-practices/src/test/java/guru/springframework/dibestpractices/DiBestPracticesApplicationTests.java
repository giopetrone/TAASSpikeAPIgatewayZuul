package guru.springframework.dibestpractices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiBestPracticesApplicationTests {

	@Test
	void contextLoads() {
	}

}
