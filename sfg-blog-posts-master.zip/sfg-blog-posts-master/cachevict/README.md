# Caching in Spring Boot RESTful Service: Part 2- Cache Eviction

This is an example to demonstrate cache eviction in a Spring Boot RESTful application published in http://www.springframework.guru
