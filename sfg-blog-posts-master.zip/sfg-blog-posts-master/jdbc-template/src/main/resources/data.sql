INSERT INTO employees (first_name, last_name, yearly_income)
VALUES ('John', 'Doe', 80000);

INSERT INTO employees (first_name, last_name, yearly_income)
VALUES ('Mary', 'Jackson', 75000);

INSERT INTO employees (first_name, last_name, yearly_income)
VALUES ('Peter', 'Grey', 60000);