package org.springframework.guru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorHandlingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
