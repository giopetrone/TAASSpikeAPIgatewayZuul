package guru.springframework.annotationbasedbeandefinitioninheritance;

import guru.springframework.annotationbasedbeandefinitioninheritance.config.AppConfig;
import guru.springframework.annotationbasedbeandefinitioninheritance.domain.EPubBook;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class AnnotationBasedBeanDefinitionInheritanceDemoApplication {

    public static void main(String[] args) {

    }

}
