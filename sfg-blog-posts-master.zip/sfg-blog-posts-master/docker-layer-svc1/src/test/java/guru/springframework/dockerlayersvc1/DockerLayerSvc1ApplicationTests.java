package guru.springframework.dockerlayersvc1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerLayerSvc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
