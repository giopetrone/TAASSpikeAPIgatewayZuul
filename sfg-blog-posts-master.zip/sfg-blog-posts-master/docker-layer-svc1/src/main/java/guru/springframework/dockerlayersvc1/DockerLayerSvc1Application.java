package guru.springframework.dockerlayersvc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerLayerSvc1Application {

	public static void main(String[] args) {
		SpringApplication.run(DockerLayerSvc1Application.class, args);
	}

}
