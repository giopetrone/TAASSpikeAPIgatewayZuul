# Spring Boot Messaging with RabbitMQ

This is an example multi-module project accompanying the post Spring Boot Messaging with RabbitMQ published in http://www.springframework.guru
