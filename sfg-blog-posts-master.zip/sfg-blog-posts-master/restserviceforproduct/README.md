# Caching in Spring Boot RESTful Service: Part 1

This is an example to demonstrate caching in a Spring Boot RESTful application published in http://www.springframework.guru
