# Using RestTemplate in Spring

Example project for blog post about using RestTemplate for consuming a REST Web-Service.