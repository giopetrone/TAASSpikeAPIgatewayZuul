package guru.springframework.maplombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaplombokApplication {

    public static void main(String[] args) {
        SpringApplication.run(MaplombokApplication.class, args);
    }

}
