package guru.springframework.maplombok.svb.model;

public enum AchService {
    STANDARD, SAME_DAY

}
