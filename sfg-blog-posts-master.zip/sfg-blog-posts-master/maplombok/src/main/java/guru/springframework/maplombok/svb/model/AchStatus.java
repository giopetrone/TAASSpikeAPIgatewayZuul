package guru.springframework.maplombok.svb.model;

/**
 * Created by jt on 1/28/21.
 */
public enum AchStatus {
    PENDING, CANCELED, PROCESSING, HOLD, SUCCEEDED, FAILED, CORRECTED
}
