package guru.springframework.maplombok.svb.model;

/**
 * Created by jt on 1/28/21.
 */
public enum SecCode {
    CCD, PPD, WEB
}
