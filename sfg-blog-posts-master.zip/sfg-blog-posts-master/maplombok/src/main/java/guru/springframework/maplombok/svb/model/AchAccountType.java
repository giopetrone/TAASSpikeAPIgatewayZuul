package guru.springframework.maplombok.svb.model;

public enum AchAccountType {
    CHECKING, SAVINGS
}
