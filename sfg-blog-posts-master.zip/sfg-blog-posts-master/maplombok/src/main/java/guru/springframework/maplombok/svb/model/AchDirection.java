package guru.springframework.maplombok.svb.model;

public enum AchDirection {
    CREDIT, DEBIT;
}
