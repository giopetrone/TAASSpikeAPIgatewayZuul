package guru.springframework.maplombok;

//@SpringBootTest
class MaplombokApplicationTests {

   // @Test
    void contextLoads() {
    }

}
