package guru.springframework.dockerlayersvc2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerLayerSvc2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
