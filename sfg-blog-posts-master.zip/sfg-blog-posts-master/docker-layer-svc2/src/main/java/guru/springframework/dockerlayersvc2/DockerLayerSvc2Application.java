package guru.springframework.dockerlayersvc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerLayerSvc2Application {

	public static void main(String[] args) {
		SpringApplication.run(DockerLayerSvc2Application.class, args);
	}

}
