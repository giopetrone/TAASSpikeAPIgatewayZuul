package guru.springframework.feign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignApplicationTests {

    @Test
    void contextLoads() {
    }

}
