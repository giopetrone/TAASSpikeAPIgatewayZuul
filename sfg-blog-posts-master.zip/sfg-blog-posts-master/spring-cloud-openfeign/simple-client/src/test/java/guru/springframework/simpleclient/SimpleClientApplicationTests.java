package guru.springframework.simpleclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
