# Argument captors in Mockito

This is an example to show how argument captors can be used in Mockito published in http://www.springframework.guru
