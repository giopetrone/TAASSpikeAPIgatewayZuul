---
name: Topic Proposal
about: Propose new Topic
title: "[PROPOSAL} -"
labels: Topic Proposal
assignees: springframeworkguru

---

**What Topic Would You Like To Write About:**
<!-- brief description of what you would like to write about -->

**Target Length:**
<!-- target number of words. Just an estimate is fine -->

**Supporting Links:**
<!-- list any relevant links here -->
