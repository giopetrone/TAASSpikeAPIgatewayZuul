---
name: New Author
about: Apply to be a SFG Author
title: ''
labels: New Author
assignees: springframeworkguru

---

**Your name:**


**Introduce yourself:**
<!-- Short introduction about you! -->

**Link to your LinkedIn Profile:**
