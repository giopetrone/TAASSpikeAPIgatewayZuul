# Comparison and Sorting with Lambda

This is an example to show how comparison and sorting is done in Java using Lambda expressions published
in http://www.springframework.guru
